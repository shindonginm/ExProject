import { useEffect, useRef } from "react";

const CustomCursor = () => {
  const cursorRef = useRef(null);
  const pos = useRef({ x: 0, y: 0 });
  const mouse = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const cursor = cursorRef.current;

    const moveCursor = (e) => {
      mouse.current.x = e.clientX;
      mouse.current.y = e.clientY;
    };

    const animate = () => {
      // 커서 위치를 부드럽게 따라가게
      pos.current.x += (mouse.current.x - pos.current.x) * 0.6;
      pos.current.y += (mouse.current.y - pos.current.y) * 0.6;

      // translate와 rotate를 한 번에 적용
      cursor.style.transform = `translate(${pos.current.x}px, ${pos.current.y}px) translate(-50%, -50%) rotate(-5deg)`;

      requestAnimationFrame(animate);
    };

    window.addEventListener("mousemove", moveCursor);
    animate();

    return () => {
      window.removeEventListener("mousemove", moveCursor);
    };
  }, []);

  return (
    <img
      ref={cursorRef}
      src="/csr.png"
      alt="cursor"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        pointerEvents: "none",
        userSelect:'none',
        width: "40px",
        height: "40px",
        zIndex: 9999,
      }}
    />
  );
};

export default CustomCursor;
