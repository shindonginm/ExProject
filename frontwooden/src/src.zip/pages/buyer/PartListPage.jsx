

const PartListPage = () => {
    return(
        <div>
            <h1>부품리스트</h1>
            
        </div>
    )
}
export default PartListPage;