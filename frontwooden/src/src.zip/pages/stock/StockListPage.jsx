

const StockListPage = () => {
  return(
    <div>
      <h2>재고리스트</h2>
    </div>
  )
}
export default StockListPage;