import axios from "axios";
import { BASE_URL } from "./PartOrderAPI";

const host = BASE_URL;

// 전체 주문 조회
export const getItemList = async () => {
    const res = await axios.get(`${host}/plan/itemlist`);
    // console.log("API 응답:", response.data);
    return res.data;
};



export const createItemList = async (formData) => {
  const res = await axios.post(`${host}/plan/itemlist`, formData, {
    headers: {
      'Content-Type': 'application/json',
    },
  });
  return res.data;
};

// 단건 수정
export const updateItemList = async (formData) => {
  const res = await axios.put(`${host}/plan/itemlist`, formData, {
    headers: { 'Content-Type': 'application/json' },
  });
  return res.data;
};

export const deleteItemList = async (itemNo) => {
  const res = await axios.delete(`${host}/plan/itemlist`, { 
    data: { itemNo } 
  });
  return res.data;
};
