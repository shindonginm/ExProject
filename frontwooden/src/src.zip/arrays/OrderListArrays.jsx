export const OrderListArr = [            
  { id: 1, clmn: "orderNo", input: "number",content: "주문번호" },
  { id: 2, clmn: "customerId", input: "number", content: "판매처번호" },
  { id: 3, clmn: "itemId", input: "number", content: "일련번호" },
  { id: 4, clmn: "orderQty", input: "number", content: "판매수량" },
  { id: 5, clmn: "orderPrice", input: "number", content: "판매단가" },
  { id: 6, clmn: "orderState", input: "text", content: "판매상태" },
  { id: 7, clmn: "orderDeliState", input: "text", content: "납품상태" },
  { id: 8, clmn: "orderDate", input: "date", content: "납품일자" },
  { id: 9, clmn: "cusAddr", input: "text", content: "판매처주소" },
];