
import { useEffect } from "react";
import { OrderListArr } from "../../arrays/OrderListArrays";
import axios from "axios";
import { useCRUD } from "../../hook/useCRUD";
import { BASE_URL } from "../../api/PartOrderAPI";



const OrderListForm = ({children}) => {
 const {
  onSubmit,
  setItemList,
  setCustomerId,
  customerId,
  customer,
  setItemListId,
  itemList,
  orderQty,
  setOrderQty,
  onChange,
  setCustomer,
 }=useCRUD({
  keyField: "orderNo"
 });
  
  useEffect(()=> {
    console.log("요청 URL:", BASE_URL);
    axios.get(`${BASE_URL}/order/sellercustomer`).then(res => {
      const options = res.data.map(temp => ({ label: temp.cusComp, value: temp.cusNo}));
      setCustomer(options);
    });
    axios.get(`${BASE_URL}/plan/itemlist`).then(res => {
      const option = res.data.map(temp => ({ label: temp.itemName, value: temp.itemList}));
      setItemList(option);
    })
  },[onsubmit])

 


  return (
    <div className="form-wrapper">
      <form onSubmit={onSubmit}>
        <p>
          <label>거래처</label>
          <select onChange={(e) => {
          setCustomerId(e.target.value ? Number(e.target.value) : null);}} required
          value={customerId ?? ""}>
          <option value="" disabled>거래처를 선택하세요</option>
          { customer.map(option => ( 
            <option key={option.value} value={option.value}>{option.label}</option>
          ))};
          </select>
        </p>
        <p>
          <label>상품</label>
          <select onChange={(e) => setItemListId(Number(e.target.value))} required>
            <option value="" disabled>상품을 선택하세요</option>
            { itemList.map(option => (
              <option key={option.value} value={option.value}>{option.label}</option>
            ))}
          </select>
        </p>

          <label>수량</label>
          <input type="number" min="1" value={orderQty} onChange={e => setOrderQty(Number(e.target.value))} required/>
          {
            OrderListArr.slice(3).map(data => (
              <p key={data.id}>
                <span className="form-child">{data.content}</span>
                <input type="text"  onChange={onChange}/>
              </p>
            ))
          }
        
        
        {children}
      </form>
    </div>
  );
};

export default OrderListForm;
